This folder contains the sql file for our database. 

-> When you implement changes to the database, export the sql file from phpMyAdmin and drop it here
-> To test changes, drop stepvadb and import this file