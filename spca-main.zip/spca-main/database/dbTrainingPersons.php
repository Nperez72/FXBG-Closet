<?php
    include_once('dbinfo.php');
    include_once(dirname(__FILE__). '/../domain/Training.php');
?>