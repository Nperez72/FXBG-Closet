<?php
$_SERVER['SERVER_NAME']='localhost';
require_once 'database/dbShifts.php';
auto_checkout_missing_shifts();
?>
